This repo is a GitHub Actions demo of publishing a React App into GitHub Pages.

View the [workflow file](./.github/workflows/ci.yml) and the [published website](https://ruanyf.github.io/github-actions-demo).

Read the details in [my blog](http://www.ruanyifeng.com/blog/2019/09/getting-started-with-github-actions.html) (in Chinese).
